package com.safeanchor;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Macro tự thiết kế: bạn xếp các bước (anchor, glowstone, obsidian, crystal, totem, chờ...) theo ý muốn trong menu,
 * rồi nhìn vào 1 block và bấm phím K: client làm lần lượt từng bước. Bước nào kẹt quá 40 tick thì bỏ qua.
 * "base" = block đang ngắm, "place" = ô trống kề mặt đang ngắm (nơi đặt anchor / obsidian / crystal).
 */
public class MacroBuilder {
    public static final String[] IDS = {"OBS", "ANCHOR", "GLOW", "OBS_SHIELD", "EXPLODE", "CRYSTAL", "HIT_CRYSTAL",
            "TOTEM", "TOTEM_OFF", "OBS_BACK", "USE", "PEARL", "ATTACK"};
    public static final String[] NAMES = {"Đặt obsidian tại ô ngắm", "Đặt respawn anchor", "Nạp glowstone vào anchor",
            "Obsidian chắn trước mình (cạnh anchor)", "Kích nổ anchor (cầm đồ khác)", "Đặt end crystal lên obsidian",
            "Đập nổ crystal", "Chuyển sang ô totem", "Totem lên tay phụ", "Obsidian sau lưng mình",
            "Chuột phải (đồ đang cầm)", "Ném ender pearl", "Đánh người gần nhất"};

    static boolean running;
    static int idx, cd, timeout;
    static BlockPos base, place;
    static List<String> seq = new ArrayList<>();

    public static String label(String step) {
        int k = step.indexOf(':');
        String id = k > 0 ? step.substring(0, k) : step;
        String arg = k > 0 ? step.substring(k + 1) : "";
        if (id.equals("WAIT")) return "Chờ " + arg + " tick";
        if (id.equals("SLOT")) return "Chọn ô hotbar " + arg;
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return NAMES[i];
        return step;
    }

    public static void start(MinecraftClient mc) {
        if (running) { running = false; Util.msg("Macro: dừng"); return; }
        if (mc.player == null || mc.world == null) return;
        Config c = Config.I;
        if (c.macroSeq.isEmpty()) { Util.warn("Macro trống: thêm bước trong menu (Hàng PvP > Macro)"); return; }
        base = null; place = null;
        if (mc.crosshairTarget instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK) {
            base = h.getBlockPos();
            place = base.offset(h.getSide());
        }
        seq = new ArrayList<>(c.macroSeq);
        idx = 0; cd = 0; timeout = 0; running = true;
        Util.msg("Macro: chạy " + seq.size() + " bước");
    }

    static void next() { idx++; timeout = 0; cd = Math.max(cd, Util.pace(Math.max(0, Config.I.comboDelay))); }

    static void stop(String why) { running = false; Util.warn(why); }

    public static void tick(MinecraftClient mc) {
        if (!running) return;
        var p = mc.player; var w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) { running = false; return; }
        if (idx >= seq.size()) { running = false; Util.msg("Macro: xong"); return; }
        if (cd > 0) { cd--; return; }
        String step = seq.get(idx);
        if (++timeout > 40) { Util.warn("Macro: bước " + (idx + 1) + " (" + label(step) + ") kẹt, bỏ qua"); next(); return; }
        if (exec(mc, step)) next();
    }

    static int num(String a, int def) {
        try { return Integer.parseInt(a.trim()); } catch (Exception e) { return def; }
    }

    static boolean exec(MinecraftClient mc, String step) {
        int k = step.indexOf(':');
        String id = k > 0 ? step.substring(0, k) : step;
        String arg = k > 0 ? step.substring(k + 1) : "";
        return switch (id) {
            case "WAIT" -> { cd = Math.max(0, num(arg, 2)); yield true; }
            case "SLOT" -> { Util.select(num(arg, 1) - 1); yield true; }
            case "OBS" -> obs(mc);
            case "ANCHOR" -> anchor(mc);
            case "GLOW" -> glow(mc);
            case "OBS_SHIELD" -> shield(mc);
            case "EXPLODE" -> explode(mc);
            case "CRYSTAL" -> crystal(mc);
            case "HIT_CRYSTAL" -> hitCrystal(mc);
            case "TOTEM" -> { Util.select(Config.I.totemSlot - 1); yield true; }
            case "TOTEM_OFF" -> totemOff(mc);
            case "OBS_BACK" -> obsBack(mc);
            case "USE" -> { mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND); yield true; }
            case "PEARL" -> pearl(mc);
            case "ATTACK" -> attack(mc);
            default -> true;
        };
    }

    static boolean needPlace() {
        if (place != null) return true;
        stop("Macro: cần nhìn vào 1 block khi bấm phím");
        return false;
    }

    static boolean isBase(BlockState st) { return st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.BEDROCK); }

    static boolean obs(MinecraftClient mc) {
        if (!needPlace()) return true;
        if (mc.world.getBlockState(place).isOf(Blocks.OBSIDIAN)) return true;
        return Util.placeBlock(place, Items.OBSIDIAN);
    }

    static boolean anchor(MinecraftClient mc) {
        if (!needPlace()) return true;
        if (mc.world.getBlockState(place).isOf(Blocks.RESPAWN_ANCHOR)) return true;
        return Util.placeBlock(place, Items.RESPAWN_ANCHOR);
    }

    static boolean glow(MinecraftClient mc) {
        if (!needPlace()) return true;
        BlockState st = mc.world.getBlockState(place);
        if (!st.isOf(Blocks.RESPAWN_ANCHOR)) return false;           // chờ anchor xuất hiện
        if (st.get(Properties.CHARGES) >= 1) return true;
        return Util.selectItem(s -> s.isOf(Items.GLOWSTONE)) && Util.useOnBlock(place, Direction.UP);
    }

    static boolean shield(MinecraftClient mc) {
        if (!needPlace()) return true;
        AnchorShield.shield(mc, place);      // chọn ô phía mình, không chắn đối thủ, không bấm vào mặt anchor
        return true;
    }

    static boolean explode(MinecraftClient mc) {
        if (!needPlace()) return true;
        Util.selectItem(s -> !s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR));
        Util.useOnBlock(place, Direction.UP);
        return true;
    }

    static boolean crystal(MinecraftClient mc) {
        var w = mc.world;
        BlockPos b = null;
        if (place != null && isBase(w.getBlockState(place))) b = place;
        else if (base != null && isBase(w.getBlockState(base))) b = base;
        if (b == null) { if (timeout > 20) stop("Macro: không có obsidian/bedrock để đặt crystal"); return false; }
        if (!Util.selectItem(s -> s.isOf(Items.END_CRYSTAL))) { stop("Macro: không có end crystal"); return true; }
        return Util.useOnBlock(b, Direction.UP);
    }

    static boolean hitCrystal(MinecraftClient mc) {
        var p = mc.player; var w = mc.world;
        EndCrystalEntity best = null; double bd = 1e9;
        for (EndCrystalEntity e : w.getEntitiesByClass(EndCrystalEntity.class, new Box(p.getPos(), p.getPos()).expand(7), x -> true)) {
            double d = Util.distToBox(p.getEyePos(), e.getBoundingBox());
            if (d > Math.max(3.0, Config.I.reach)) continue;
            if (Util.selfDamage(p, e.getPos()) >= p.getHealth() + p.getAbsorptionAmount()) continue;   // không tự sát
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) return false;                              // chờ crystal xuất hiện
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    static boolean totemOff(MinecraftClient mc) {
        var p = mc.player;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return true;
        var inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) { Util.click(Util.screenSlot(i), 40, SlotActionType.SWAP); return true; }
        }
        Util.warn("Macro: không có totem");
        return true;
    }

    static boolean obsBack(MinecraftClient mc) {
        var p = mc.player; var w = mc.world;
        BlockPos b = p.getBlockPos().offset(p.getHorizontalFacing().getOpposite());
        if (!w.getBlockState(b).isReplaceable()) return true;
        return Util.placeBlock(b, Items.OBSIDIAN);
    }

    static boolean pearl(MinecraftClient mc) {
        if (!Util.selectItem(s -> s.isOf(Items.ENDER_PEARL))) { Util.warn("Macro: không có ender pearl"); return true; }
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        return true;
    }

    static boolean attack(MinecraftClient mc) {
        var p = mc.player;
        PlayerEntity t = Util.nearestEnemy(Math.max(3.0, Config.I.reach));
        if (t == null) return true;
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }
}
