package com.safeanchor;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

/** Một module trong client. Mỗi module có phím tắt riêng + danh sách Setting. */
public class Module {
    public enum Cat { COMBAT("COMBAT"), MOVEMENT("MOVEMENT"), PLAYER("PLAYER"), RENDER("RENDER"), WORLD("WORLD"), MISC("MISC"), HUD("HUD");
        public final String label; Cat(String l) { label = l; } }

    public final String name, desc; public final Cat cat;
    public boolean enabled;
    public final Setting.Key bind = new Setting.Key("Keybind");
    public final List<Setting> settings = new ArrayList<>();
    public boolean expanded;   // bảng cài đặt đang mở (chuột phải)

    public Module(String name, String desc, Cat cat) { this.name = name; this.desc = desc; this.cat = cat; }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    // Module nối với tính năng có sẵn của client (Config): bật/tắt + cài đặt đồng bộ 2 chiều
    public java.util.function.BooleanSupplier ext;
    public java.util.function.Consumer<Boolean> extSet;
    public Runnable apply;          // đẩy giá trị Setting sang Config (chạy mỗi tick)
    public boolean implemented = true;

    public boolean isOn() { return ext != null ? ext.getAsBoolean() : enabled; }
    public void toggle() { setEnabled(!isOn()); }
    public void setEnabled(boolean v) {
        if (v == isOn()) return;
        enabled = v;
        if (extSet != null) extSet.accept(v);
        try { if (v) onEnable(); else onDisable(); } catch (Throwable t) { t.printStackTrace(); }
        Config.save(); ModuleManager.save();
    }

    public void onEnable() {}
    public void onDisable() {}
    /** Gọi mỗi tick khi module đang bật và đang trong thế giới. */
    public void onTick(MinecraftClient mc) {}
    /** Gọi mỗi frame HUD khi module đang bật (module tab HUD dùng). */
    public void onHud(net.minecraft.client.gui.DrawContext ctx, MinecraftClient mc) {}
}
