package com.safeanchor.mixin;

import com.safeanchor.TpGlide;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Trượt mượt khi tp: sau khi camera tính xong vị trí thì cộng thêm độ lệch của TpGlide. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);

    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void lananh$glide(BlockView area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        Vec3d o = TpGlide.offset();
        if (o == null) return;
        Camera self = (Camera) (Object) this;
        Vec3d p = self.getPos();
        setPos(p.x + o.x, p.y + o.y, p.z + o.z);
    }
}
