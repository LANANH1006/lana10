package com.safeanchor;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Trang "Dò căn cứ" + "Cài đặt module" (chuột phải vào module, hoặc bấm nút ⚙). */
public class Pages4 {
    static Config C() { return Config.I; }

    static final String[][] SUS_CATS = {
        {"deepslate", "Deepslate nhân tạo (polished / bricks / tiles)"},
        {"bricks", "Gạch / đá chế tạo / concrete"},
        {"cobble", "Cobblestone (đá cuội)"},
        {"planks", "Gỗ chế tạo: ván / cửa / hàng rào / biển"},
        {"glass", "Kính"},
        {"storage", "Rương / thùng / shulker"},
        {"utility", "Lò / bàn chế tạo / giường / anvil / enchant"},
        {"redstone", "Redstone / piston / hopper / TNT"},
        {"obsidian", "Obsidian / anchor / netherite"},
        {"rails", "Đường ray"},
    };
    static final String[] MODES = {"Safe (chậm, giống người)", "Risk (vừa)", "Unsafe (tối đa)"};

    public static Screen base(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        Map<Integer, Runnable> rc = new HashMap<>();
        for (String id : new String[]{"sus", "spawner", "storage", "hole", "light", "chunk"}) {
            Mods.Mod mod = Mods.find(id);
            rc.put(m.size(), () -> Pages.open(pp -> settings(id, pp)));
            m.add(Pages.toggle(mod.name(), mod.get(), mod.set()));
            m.add(Pages.button("   ⚙ Cài đặt: " + id, () -> Pages.open(pp -> settings(id, pp))));
        }
        MenuScreen s = new MenuScreen("Dò căn cứ (chuột phải vào module = cài đặt)", p, m);
        s.rightActions = rc;
        return s;
    }

    static String keyLabel(int k) {
        if (k < 32) return "Phím tắt: §7chưa gán §f(bấm để gán)";
        String n;
        try { n = InputUtil.fromKeyCode(k, 0).getLocalizedText().getString(); } catch (Throwable t) { n = "#" + k; }
        return "Phím tắt: §e" + n + " §f(bấm để đổi)";
    }

    public static Screen settings(String id, Screen p) {
        Mods.Mod mod = Mods.find(id);
        Mods.Cfg g = Mods.cfg(id);
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle(mod.name(), mod.get(), mod.set()));
        String f = mod.flags();
        if (f.contains("a")) m.add(Pages.slider("Alpha / độ mờ (gợi ý Sus ESP: 41-65)", 5, 200, true, () -> g.alpha, v -> g.alpha = (int) v));
        if (f.contains("y")) {
            m.add(Pages.slider("Min Y", -64, 320, true, () -> g.minY, v -> g.minY = (int) v));
            m.add(Pages.slider("Max Y", -64, 320, true, () -> g.maxY, v -> g.maxY = (int) v));
        }
        if (f.contains("r")) m.add(Pages.slider("Tầm quét (block)", 8, 128, true, () -> g.range, v -> g.range = (int) v));
        if (f.contains("c")) m.add(Pages.color(f.contains("2") ? "khung an toàn (obsidian/bedrock)" : "khung", () -> g.color, v -> g.color = v));
        if (f.contains("2")) m.add(Pages.color("khung không an toàn", () -> g.color2, v -> g.color2 = v));
        if (f.contains("f")) {
            for (String[] cat : SUS_CATS) {
                String key = cat[0];
                m.add(Pages.toggle("Quét: " + cat[1], () -> !g.off.contains(key), v -> { g.off.remove(key); if (!v) g.off.add(key); }));
            }
        }
        return new MenuScreen("Cài đặt: " + mod.name(), p, m);
    }
}
