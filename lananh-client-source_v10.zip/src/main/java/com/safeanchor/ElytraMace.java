package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Elytra + Mace tự động.
 * Bình thường: cất cánh -> bay lên cao hơn đối thủ -> (cánh -> áo, vì mace chỉ smash khi KHÔNG bay) -> rơi xuống đập.
 * Chuỗi đập: vừa đập xong bị hất lên nhẹ -> KHÔNG bay lên cao nữa, dùng cánh lao thẳng xuống đối thủ rồi đập tiếp.
 */
public class ElytraMace {
    static boolean diving, keysHeld, quick, hitFlag;
    static int stage;   // 0 = còn đeo cánh, bay tới gần đối thủ; 1 = đã đổi áo, rơi đập
    static int cd, rocketCd, axeCd;
    public static int chain;   // số tick còn lại của "chuỗi đập"
    static double tvx, tvz;    // vận tốc ngang của đối thủ (block / tick)
    static PlayerEntity lastT; static Vec3d lastTp;

    public static void toggle(MinecraftClient mc) {
        Config.I.autoMace = !Config.I.autoMace;
        if (!Config.I.autoMace) release(mc);
        Util.msg("Elytra Mace: " + (Config.I.autoMace ? "§aBẬT" : "§cTẮT"));
        Config.save();
    }

    /** Gọi mỗi khi đập đối thủ bằng mace (tự đập hoặc bạn tự bấm). */
    public static void onHit() {
        if (!Config.I.autoMace) return;
        if (Config.I.maceChain) chain = 45;
        hitFlag = true;
    }

    static void release(MinecraftClient mc) {
        if (keysHeld) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); keysHeld = false; }
        diving = false; stage = 0; quick = false; hitFlag = false;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        var p = mc.player;
        if (!c.autoMace || !c.enabled || p == null || mc.world == null || mc.interactionManager == null) { if (keysHeld) release(mc); return; }
        if (p.isSpectator() || p.isDead()) return;
        if (cd > 0) cd--;
        if (rocketCd > 0) rocketCd--;
        if (axeCd > 0) axeCd--;
        if (chain > 0) chain--;

        PlayerEntity t = Util.nearestEnemy(c.maceRange);
        if (t == null) { release(mc); lastT = null; return; }
        if (lastT == t && lastTp != null) { tvx = t.getX() - lastTp.x; tvz = t.getZ() - lastTp.z; } else { tvx = 0; tvz = 0; }
        lastT = t; lastTp = t.getPos();

        if (p.getHealth() + p.getAbsorptionAmount() < c.minSelfHealth) {
            release(mc);
            if (c.maceSwapChest && cd == 0 && Util.chestIs(Util::isElytra)) { Util.equipChest(Util::isChestplate, true); cd = 5; }
            Util.warn("Máu thấp - Elytra Mace tạm dừng");
            return;
        }

        switch (c.maceView) {
            case 1 -> mc.options.setPerspective(Perspective.FIRST_PERSON);
            case 2 -> mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            case 3 -> mc.options.setPerspective(Perspective.THIRD_PERSON_FRONT);
            default -> {}
        }

        double above = p.getY() - t.getY();
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());

        if (diving) { dive(mc, t, dist); return; }
        hitFlag = false;

        // ===== CHUỖI ĐẬP: vừa đập, đang bị hất lên nhẹ -> đeo cánh rồi lao xuống đập tiếp =====
        if (c.maceChain && chain > 0 && !p.isOnGround() && horiz <= c.maceHorizDive) {
            if (cd > 0) return;
            if (!Util.chestIs(Util::isElytra)) { if (Util.equipChest(Util::isElytra, false)) cd = 2; return; }
            diving = true; stage = 0; quick = true; cd = 0;
            return;
        }

        // ===== GIAI ĐOẠN BAY LÊN =====
        if (cd > 0) return;
        if (!Util.chestIs(Util::isElytra)) {
            if (Util.equipChest(Util::isElytra, false)) { cd = 3; } else { Util.warn("Không có elytra trong túi!"); }
            return;
        }
        if (p.isOnGround()) {                       // cất cánh
            mc.options.jumpKey.setPressed(true); keysHeld = true; return;
        }
        mc.options.jumpKey.setPressed(false);
        if (!p.isGliding()) {                       // bắt đầu bay giữa không trung
            if (p.getVelocity().y < 0) {
                p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                p.startGliding();
            }
            return;
        }
        Vec3d aim = new Vec3d(t.getX(), t.getY() + c.maceDiveDist + 8, t.getZ());
        Util.aim(p, aim);
        rocket(mc);
        if (above >= c.maceDiveDist && horiz <= c.maceHorizDive) { diving = true; stage = 0; quick = false; cd = 0; }
    }

    /** Chỉ bắn pháo khi đang bay lên / bay ngang. Đang rơi hoặc đang chúi mũi xuống thì KHÔNG bắn (pháo sẽ đẩy xuống làm vọt qua mục tiêu). */
    static boolean rocket(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.maceUseRocket || rocketCd > 0 || p.getVelocity().length() >= 1.1) return false;
        if (p.getVelocity().y < -0.3 || p.getPitch() > 5f) return false;
        if (!Util.selectItem(s -> s.isOf(Items.FIREWORK_ROCKET))) return false;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        rocketCd = 14;
        return true;
    }

    /** Mô phỏng rơi tự do (bỏ cánh) từ trạng thái hiện tại xuống thấp h block: {số tick, trôi x, trôi z}. */
    static double[] fallSim(net.minecraft.client.network.ClientPlayerEntity p, double h) {
        Vec3d v = p.getVelocity();
        double y = 0, x = 0, z = 0, vy = v.y, vx = v.x, vz = v.z;
        int n = 0;
        while (y > -h && n < 160) {
            vy = (vy - 0.08) * 0.98; y += vy;
            x += vx; z += vz; vx *= 0.91; vz *= 0.91;
            n++;
        }
        return new double[]{n, x, z};
    }

    /** Bỏ lượt / đập xong: đeo lại cánh (cd ngắn) và làm vòng mới. */
    private static void abort(MinecraftClient mc) { release(mc); cd = 1; }

    private static void dive(MinecraftClient mc, PlayerEntity t, double dist) {
        Config c = Config.I; var p = mc.player;
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double above = p.getY() - t.getY();
        if (!t.isAlive()) { abort(mc); return; }

        // ===== GIAI ĐOẠN 0: vẫn đeo cánh, bay (lao) tới sát đối thủ =====
        if (stage == 0) {
            if (!Util.chestIs(Util::isElytra)) {
                if (cd == 0 && Util.equipChest(Util::isElytra, false)) cd = 3;
                return;
            }
            if (!p.isGliding()) {
                if (p.isOnGround()) { abort(mc); return; }
                if (p.getVelocity().y < 0) {        // đợi hết đà bị hất lên rồi mới mở cánh
                    p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                    p.startGliding();
                }
                return;
            }
            if (horiz > c.maceHorizDive + 10 || above < (quick ? -1.0 : 2.0)) { abort(mc); return; }   // đối thủ chạy/pearl đi chỗ khác
            if (!quick && c.maceBallistic) {
                // Lao chéo vào người sẽ bị cánh đổi đà thành bay vọt lên qua đầu. Thay vào đó: bay ngang phía trên đầu,
                // tính đà rơi, tới điểm mà "thả ra là rơi trúng đầu" thì đổi áo + rơi thẳng xuống.
                double head = t.getY() + t.getHeight();
                double[] sim = fallSim(p, p.getY() - head);
                double err = Math.hypot(p.getX() + sim[1] - (t.getX() + tvx * sim[0]), p.getZ() + sim[2] - (t.getZ() + tvz * sim[0]));
                boolean high = p.getY() - head >= Math.max(5.0, c.maceDiveDist * 0.6);
                if (high && err <= c.maceDropErr) { stage = 1; cd = 0; return; }
                Vec3d to = high ? new Vec3d(t.getX() + tvx * 4, p.getEyeY(), t.getZ() + tvz * 4)
                                : new Vec3d(t.getX(), t.getY() + c.maceDiveDist + 8, t.getZ());
                Util.aim(p, to);
                rocket(mc);
                return;
            }
            Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
            rocket(mc);
            double swap = quick ? c.maceChainSwap : c.maceSwapDist;
            if (dist <= swap && above > (quick ? 0.5 : 3.0)) { stage = 1; cd = 0; }
            return;
        }

        // ===== GIAI ĐOẠN 1: đổi sang áo (hết bay), rơi xuống đập =====
        if (hitFlag) { hitFlag = false; abort(mc); return; }                            // bạn vừa tự đập xong -> làm vòng mới
        double abortH = (!quick && c.maceBallistic) ? c.maceHorizDive + 12 : c.maceAbortDist;   // thả từ xa nên cho phép lệch ngang lớn hơn
        if (horiz > abortH || above < (quick ? -0.5 : 0)) { abort(mc); return; }
        if (c.maceSwapChest && (p.isGliding() || Util.chestIs(Util::isElytra))) {
            if (cd == 0) { Util.equipChest(Util::isChestplate, true); cd = 2; }
            if (p.isGliding()) p.stopGliding();
            return;
        }
        // đối thủ đang giơ khiên chặn -> đổi rìu đập phá khiên trước
        if (c.maceAxe && c.maceAutoHit && t.isBlocking() && dist <= c.maceHitDist && Util.has(s -> s.isIn(ItemTags.AXES))) {
            Util.selectItem(s -> s.isIn(ItemTags.AXES));
            Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
            mc.options.forwardKey.setPressed(true); keysHeld = true;
            if (axeCd == 0 && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
                mc.interactionManager.attackEntity(p, t);
                p.swingHand(Hand.MAIN_HAND);
                axeCd = 12;
            }
            return;
        }
        if (!Util.selectItem(s -> s.isOf(Items.MACE))) { Util.warn("Không có mace!"); release(mc); return; }
        Util.aim(p, t.getPos().add(0, t.getHeight() * (c.maceBallistic ? 1.0 : 0.5), 0));
        if (horiz > 0.8) { mc.options.forwardKey.setPressed(true); keysHeld = true; } else mc.options.forwardKey.setPressed(false);

        // mace smash (rơi > 1.5 block, không bay) KHÔNG cần cooldown đầy -> đập ngay khi tới tầm, đừng chờ rồi lướt qua đầu
        boolean smash = p.fallDistance > 1.5 && !p.isGliding();
        if (c.maceAutoHit && dist <= c.maceHitDist && (smash || p.getAttackCooldownProgress(0.5f) >= 0.9f)) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            if (c.maceChain) chain = 45;
            abort(mc);          // đập xong: đeo cánh lại, bị hất nhẹ thì lao xuống đập tiếp
        }
    }
}
